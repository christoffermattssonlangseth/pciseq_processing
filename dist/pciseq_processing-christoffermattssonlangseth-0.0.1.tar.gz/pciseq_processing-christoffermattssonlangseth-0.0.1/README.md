# processing of pciseq input and output
this package can be used up- and downstream of pciseq.  
